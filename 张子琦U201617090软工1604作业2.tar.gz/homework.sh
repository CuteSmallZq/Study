#!/bin/bash
#
let COUNTS=0

echo "Please enter a file:"
read FILE

if [ -e $FILE -a -f $FILE ];then
  while read LINE
    do
      echo $LINE
      COUNTS=$(($COUNTS+1))
    done<$FILE 
  echo "There are $COUNTS line."
fi
